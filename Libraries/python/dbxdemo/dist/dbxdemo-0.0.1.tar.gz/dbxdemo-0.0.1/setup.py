from setuptools import setup

setup(name='dbxdemo',
      version='0.0.1',
      description='A sample PySpark application',
      author='Enrico Vergata',
      author_email='enrico.vergata@st.com',
      url='www.st.com',
      packages=['dbxdemo'],
      zip_safe=False)